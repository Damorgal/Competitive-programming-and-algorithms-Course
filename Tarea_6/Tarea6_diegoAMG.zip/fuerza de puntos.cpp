#include <iostream>
#include <stdio.h>
#include <vector>
#include <queue>
#include <cstring>
#include <stdlib.h>
#include <algorithm>

using namespace std;

int* fuerza_On2(int *pts[], const int n);
int* fuerza_Onlogn(int *pts[], const int n);
void fuerza_DyV(int *pts[], int a, int b, int fuerzas[]);
void Qsort(int *pts[], int a, int b);

int main()  {
    int n;
    cin >> n;
    cout<<"ola";
    int **pts=(int**)malloc(n*sizeof(int*));
    for(int i=0; i<n; i++)
        pts[i]=(int*)malloc(2*sizeof(int));
    for(int i=0; i<n; i++)
    	scanf("%d %d", &pts[i][0], &pts[i][1]);

    int *f1=fuerza_On2(pts,n);
    int *f2=fuerza_Onlogn(pts,n);
    printf("Las fuerzas con O(N^2):\n");
    for(int i=0; i<n; i++)
    	printf("%d ",f1[i]);
    printf("\nLas fuerzas con O(NlogN): (Recordar que los datos estan ordenados aqui)\n");
    for(int i=0; i<n; i++)
    	printf("%d ",f2[i]);
    int dif=0;
    for(int i=0; i<n; i++)
    	dif += f1[i]-f2[i];
    printf("\nLa diferencia de las fuerzas es: %d\n",dif);

    for(int i=0; i<n; i++)
        free(pts[i]);
    free(pts);
    return 0;
}

int* fuerza_On2(int *pts[], const int n)	{
	int *fuerzas=(int*)malloc(n*sizeof(int));
	for(int i=0; i<n; i++)	{
		fuerzas[i]=0;
		for(int j=0; j<n; j++)
			if(pts[i][0] <= pts[j][0] && pts[i][1] <= pts[j][1] && i!=j)
				fuerzas[i]++;
	}
	return fuerzas;
}

int* fuerza_Onlogn(int *pts[], const int n)	{
	Qsort(pts,0,n-1);
	int *fuerzas=(int*)calloc(n,sizeof(int));
	fuerza_DyV(pts,0,n-1,fuerzas);
	return fuerzas;
}

void fuerza_DyV(int *pts[], int a, int b, int fuerzas[])	{
	if(a==b)
		return;
	else	{
		fuerza_DyV(pts,a,(a+b)/2,fuerzas);
		fuerza_DyV(pts,(a+b)/2+1,b,fuerzas);
		for(int i=a; i<=(a+b)/2; i++)	{
			for(int j=(a+b)/2+1; j<=b; j++)
				if(pts[i][1] <= pts[j][1])
					fuerzas[i]++;
		}
	}
}

void Qsort(int *pts[], int a, int b)	{
	if(b<=a)
		return;
	else	{
		//Eleccion de pivote
		int pivote = pts[b][0];
		//Reposicionamiento de pivote
		int i=a, j=b;
		for(; i<j; i++, j--)	{
			if(pts[i][0] > pivote && pts[j][0] < pivote)	{
				int *aux = pts[i];
				pts[i] = pts[j];
				pts[j] = aux;
			}
		}
		pivote = i; //Indice del numero pivote
		//Realizamos el algoritmo
		i=a; j=b;
		while(i<j)	{
			for(; pts[i][0] < pts[pivote][0]; i++);
			for(; pts[j][0] > pts[pivote][0]; j--);
			if(i!=pivote && j!=pivote)	{
				int *aux = pts[i];
				pts[i] = pts[j];
				pts[j] = aux;
			}
			else	{
				if(i==pivote && j==pivote)
					break;
				if(pts[i][0]!=pts[j][0])	{
					if(i==pivote)	{
						int *aux = pts[i];
						pts[i] = pts[j];
						pts[j] = aux;
						pivote = j;
					}
					else	{
						int *aux = pts[i];
						pts[i] = pts[j];
						pts[j] = aux;
						pivote = i;
					}
				}
				else	{
					if(i==pivote)   {
                        if(pts[i][1]>pts[j][1]) {
                            int *aux = pts[i];
                            pts[i] = pts[j];
                            pts[j] = aux;
                            pivote = j;
                            i++;
                        }
                        else j--;
					}
					else    {
                        if(pts[i][1]>pts[j][1]) {
                            int *aux = pts[i];
                            pts[i] = pts[j];
                            pts[j] = aux;
                        }
                        i++;
					}
				}
			}
		}
		Qsort(pts,pivote+1,b);
		Qsort(pts,a,pivote-1);
	}
}
